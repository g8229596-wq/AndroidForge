# CHRONO — Smart Personal Planner & Music Player

CHRONO is a production-grade, offline-first Android application uniting a smart daily planner, persistent scratchpad notes, exact alarms, countdown timers, and a local music player into a minimal, futuristic dark-first interface.

---

## 🌟 Key Features

### 1. Main Dashboard
- **Personalized Live Greeting**: Updates automatically based on current time of day.
- **Futuristic Chrono Clock**: Live digital clock display with sleek neon glow accents.
- **Daily Momentum Ring**: Animated progress visualization calculating completed vs. remaining scheduled tasks.
- **Today's Agenda Timeline**: Directly toggle task completion from the home screen.
- **Upcoming Alarms Card**: Shows the next scheduled alarm and exact time remaining.
- **Quick-Add Floating Action Button**: Fast task creation with zero friction.
- **Persistent Mini Player**: Floats smoothly above the bottom navigation bar whenever music is playing.

### 2. Planner & Schedule
- **Task Management**: Title, description, due date, optional due time, priority (Low, Medium, High), category, and notifications.
- **Date Filters**: Quick tabs for Today, Tomorrow, Upcoming, and All.
- **Categories**: Organize tasks into "General", "Focus & Work", "Personal", "Health & Habit", and "Creative".
- **Dynamic Sorting & Search**: Instant real-time search with togglable sorting by Due Time or Priority.
- **Confirmation Protection**: Confirmation dialog before deleting tasks.

### 3. Alarms & Countdown Timers
- **Exact Alarms**: Uses Android `AlarmManager.setExactAndAllowWhileIdle()` to guarantee wake-ups during Doze mode.
- **Recurring Schedules**: Select individual days of the week (Mon–Sun) with automated rescheduling.
- **Reboot Resilience**: `BootReceiver` restores and reschedules all active alarms upon device reboot, clock time change, or timezone adjustment.
- **Countdown Timers**: Clean circular progress visualization, preset duration shortcuts (1m, 5m, 15m, 25m Pomodoro, 45m), custom duration picker, vibration toggle, and full dismiss sound alerts.

### 4. Local Music Player
- **MediaStore Audio Scanner**: Automatically indexes audio files on device with title, artist, album, duration, and album artwork.
- **Storage Access Framework (SAF)**: Direct file importer button allowing users to pick audio files from any folder or external storage.
- **Media3 ExoPlayer & MediaSessionService**: Background playback support with system media notification controls (play, pause, next, previous, seek) and lock screen integration.
- **Now Playing Screen**: Expanded view with artwork (or futuristic dynamic gradient visualizer), seekbar scrubber, shuffle, repeat (Off, One, All), and interactive queue drawer.
- **Favorites & Search**: Star favorite songs and filter library instantly.

### 5. Persistent Local Storage & Backup
- **Room Database**: 100% offline local storage for tasks, notes, alarms, and categories.
- **Jetpack DataStore**: High-performance preferences for theme mode, accent colors, and audio playback settings.
- **JSON Backup & Restore**: Export all data into a user-selected JSON file and restore anytime without cloud lock-in.

---

## 🛠 Technology Stack
- **Language**: Kotlin 2.2.10
- **UI Framework**: Jetpack Compose with Material Design 3
- **Local Database**: Room 2.7.0 (with KSP compiler)
- **Preferences**: Jetpack DataStore Preferences 1.1.7
- **Audio Engine**: AndroidX Media3 ExoPlayer 1.5.1 & MediaSessionService
- **Image Loading**: Coil Compose 2.7.0
- **Concurrency**: Kotlin Coroutines & Flow
- **Architecture**: MVVM with Repository Pattern
