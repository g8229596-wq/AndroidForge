package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.local.ChronoDatabase
import com.example.domain.alarm.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            Log.d("BootReceiver", "Device boot/time change detected: $action. Rescheduling alarms...")

            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = ChronoDatabase.getDatabase(context)
                    val activeAlarms = db.alarmDao().getActiveAlarmsSnapshot()
                    val scheduler = AlarmScheduler(context)

                    for (alarm in activeAlarms) {
                        scheduler.scheduleAlarm(alarm)
                    }

                    val todayTasks = db.taskDao().getAllTasksSnapshot().filter { it.hasReminder && !it.isCompleted }
                    for (task in todayTasks) {
                        scheduler.scheduleTaskReminder(task)
                    }
                    Log.d("BootReceiver", "Successfully rescheduled ${activeAlarms.size} alarms and ${todayTasks.size} task reminders")
                } catch (e: Exception) {
                    Log.e("BootReceiver", "Error rescheduling alarms on boot: ${e.message}")
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
