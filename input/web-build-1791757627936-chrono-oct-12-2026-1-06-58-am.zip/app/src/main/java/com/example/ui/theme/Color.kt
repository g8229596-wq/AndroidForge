package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Backgrounds & Surfaces (Dark-First)
val ChronoBackgroundDark = Color(0xFF0B0B0F)
val ChronoSurfaceDark = Color(0xFF14141C)
val ChronoSurfaceVariantDark = Color(0xFF1C1C26)
val ChronoSurfaceElevatedDark = Color(0xFF242432)
val ChronoBorderDark = Color(0xFF2E2E3E)

// Text Colors
val ChronoTextPrimaryDark = Color(0xFFF5F5FA)
val ChronoTextSecondaryDark = Color(0xFF9494A8)
val ChronoTextTertiaryDark = Color(0xFF6B6B7F)

// Accents - Electric Violet (Default)
val ChronoViolet = Color(0xFF8B5CF6)
val ChronoVioletLight = Color(0xFFA78BFA)
val ChronoVioletDark = Color(0xFF6D28D9)
val ChronoVioletGlow = Color(0x338B5CF6)

// Accent Options
val ChronoEmerald = Color(0xFF10B981)
val ChronoEmeraldLight = Color(0xFF34D399)

val ChronoRose = Color(0xFFF43F5E)
val ChronoRoseLight = Color(0xFFFB7185)

val ChronoCyan = Color(0xFF06B6D4)
val ChronoCyanLight = Color(0xFF22D3EE)

val ChronoAmber = Color(0xFFF59E0B)
val ChronoAmberLight = Color(0xFFFBBF24)

// Light Theme Palette
val ChronoBackgroundLight = Color(0xFFF6F7FB)
val ChronoSurfaceLight = Color(0xFFFFFFFF)
val ChronoSurfaceVariantLight = Color(0xFFEEF0F7)
val ChronoSurfaceElevatedLight = Color(0xFFE4E7F2)
val ChronoBorderLight = Color(0xFFDCDFEA)
val ChronoTextPrimaryLight = Color(0xFF0F0F17)
val ChronoTextSecondaryLight = Color(0xFF5F5F73)
val ChronoTextTertiaryLight = Color(0xFF8A8A9E)
