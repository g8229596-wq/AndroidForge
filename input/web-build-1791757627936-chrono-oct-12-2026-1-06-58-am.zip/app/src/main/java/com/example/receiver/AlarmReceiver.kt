package com.example.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.ChronoDatabase
import com.example.domain.alarm.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TRIGGER_ALARM = "com.aistudio.chrono.ACTION_TRIGGER_ALARM"
        const val ACTION_TRIGGER_TIMER = "com.aistudio.chrono.ACTION_TRIGGER_TIMER"
        const val ACTION_TRIGGER_REMINDER = "com.aistudio.chrono.ACTION_TRIGGER_REMINDER"
        const val ACTION_DISMISS_ALARM = "com.aistudio.chrono.ACTION_DISMISS_ALARM"
        const val ACTION_DISMISS_TIMER = "com.aistudio.chrono.ACTION_DISMISS_TIMER"

        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_RINGTONE_URI = "extra_ringtone_uri"
        const val EXTRA_VIBRATE = "extra_vibrate"
        const val EXTRA_TASK_ID = "extra_task_id"

        const val CHANNEL_ALARMS = "chrono_alarms_channel"
        const val CHANNEL_TIMERS = "chrono_timers_channel"
        const val CHANNEL_REMINDERS = "chrono_reminders_channel"

        private var activeRingtone: Ringtone? = null

        fun stopActiveRingtone() {
            activeRingtone?.let {
                if (it.isPlaying) {
                    it.stop()
                }
            }
            activeRingtone = null
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.d("AlarmReceiver", "Received action: $action")

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        ensureNotificationChannels(context, notificationManager)

        when (action) {
            ACTION_DISMISS_ALARM -> {
                val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, 0L)
                notificationManager.cancel(alarmId.toInt())
                stopActiveRingtone()
            }
            ACTION_DISMISS_TIMER -> {
                notificationManager.cancel(99999)
                stopActiveRingtone()
            }
            ACTION_TRIGGER_ALARM -> {
                val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, 0L)
                val label = intent.getStringExtra(EXTRA_ALARM_LABEL) ?: "Alarm"
                val ringtoneUriStr = intent.getStringExtra(EXTRA_RINGTONE_URI)
                val vibrate = intent.getBooleanExtra(EXTRA_VIBRATE, true)

                playAlarmAlert(context, ringtoneUriStr, vibrate)
                showAlarmNotification(context, notificationManager, alarmId, label)

                // If recurring alarm, reschedule next occurrence!
                rescheduleIfRecurring(context, alarmId)
            }
            ACTION_TRIGGER_TIMER -> {
                val label = intent.getStringExtra(EXTRA_ALARM_LABEL) ?: "Timer Complete"
                val vibrate = intent.getBooleanExtra(EXTRA_VIBRATE, true)

                playAlarmAlert(context, null, vibrate)
                showTimerNotification(context, notificationManager, label)
            }
            ACTION_TRIGGER_REMINDER -> {
                val taskId = intent.getLongExtra(EXTRA_TASK_ID, 0L)
                val title = intent.getStringExtra(EXTRA_ALARM_LABEL) ?: "Task Reminder"
                showReminderNotification(context, notificationManager, taskId, title)
            }
        }
    }

    private fun playAlarmAlert(context: Context, ringtoneUriStr: String?, vibrate: Boolean) {
        try {
            stopActiveRingtone()
            val uri = if (!ringtoneUriStr.isNullOrBlank()) {
                Uri.parse(ringtoneUriStr)
            } else {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            }

            val ringtone = RingtoneManager.getRingtone(context, uri)
            ringtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ringtone?.play()
            activeRingtone = ringtone

            if (vibrate) {
                vibrateDevice(context)
            }
        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Error playing ringtone: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrateDevice(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager =
                    context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                val vibrator = vibratorManager.defaultVibrator
                val pattern = longArrayOf(0, 500, 300, 500, 300, 500)
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val pattern = longArrayOf(0, 500, 300, 500, 300, 500)
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    vibrator.vibrate(1000)
                }
            }
        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Vibration error: ${e.message}")
        }
    }

    private fun showAlarmNotification(
        context: Context,
        notificationManager: NotificationManager,
        alarmId: Long,
        label: String
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            alarmId.toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val dismissIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_DISMISS_ALARM
            putExtra(EXTRA_ALARM_ID, alarmId)
        }
        val dismissPendingIntent = PendingIntent.getBroadcast(
            context,
            (alarmId + 50000).toInt(),
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ALARMS)
            .setSmallIcon(R.drawable.ic_launcher_chrono)
            .setContentTitle("CHRONO Alarm: $label")
            .setContentText("Tap to open CHRONO or dismiss below")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .addAction(0, "Dismiss", dismissPendingIntent)
            .setFullScreenIntent(openPendingIntent, true)
            .build()

        notificationManager.notify(alarmId.toInt(), notification)
    }

    private fun showTimerNotification(
        context: Context,
        notificationManager: NotificationManager,
        label: String
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            99999,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val dismissIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_DISMISS_TIMER
        }
        val dismissPendingIntent = PendingIntent.getBroadcast(
            context,
            99998,
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_TIMERS)
            .setSmallIcon(R.drawable.ic_launcher_chrono)
            .setContentTitle("CHRONO Timer")
            .setContentText(label)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .addAction(0, "Stop", dismissPendingIntent)
            .build()

        notificationManager.notify(99999, notification)
    }

    private fun showReminderNotification(
        context: Context,
        notificationManager: NotificationManager,
        taskId: Long,
        title: String
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            taskId.toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_launcher_chrono)
            .setContentTitle("CHRONO Reminder")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .build()

        notificationManager.notify((taskId + 100_000).toInt(), notification)
    }

    private fun rescheduleIfRecurring(context: Context, alarmId: Long) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = ChronoDatabase.getDatabase(context)
                val alarm = db.alarmDao().getAlarmById(alarmId)
                if (alarm != null) {
                    if (alarm.isRecurring()) {
                        AlarmScheduler(context).scheduleAlarm(alarm)
                    } else {
                        // One-time alarm triggered: mark as disabled in DB
                        db.alarmDao().updateAlarmStatus(alarmId, false)
                    }
                }
            } catch (e: Exception) {
                Log.e("AlarmReceiver", "Failed to reschedule alarm: ${e.message}")
            }
        }
    }

    private fun ensureNotificationChannels(context: Context, manager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val alarmChannel = NotificationChannel(
                CHANNEL_ALARMS,
                "CHRONO Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Critical sound and heads-up alarms"
                enableVibration(true)
            }

            val timerChannel = NotificationChannel(
                CHANNEL_TIMERS,
                "CHRONO Timers",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Timer completion alerts"
                enableVibration(true)
            }

            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "CHRONO Task Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Scheduled daily task notifications"
            }

            manager.createNotificationChannel(alarmChannel)
            manager.createNotificationChannel(timerChannel)
            manager.createNotificationChannel(reminderChannel)
        }
    }
}
