package com.example.data.backup

import android.content.Context
import android.net.Uri
import com.example.data.model.AlarmEntity
import com.example.data.model.CategoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.TaskEntity
import com.example.data.repository.ChronoRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class BackupResult(
    val success: Boolean,
    val tasksCount: Int = 0,
    val notesCount: Int = 0,
    val alarmsCount: Int = 0,
    val categoriesCount: Int = 0,
    val errorMessage: String? = null
)

class BackupManager(
    private val context: Context,
    private val repository: ChronoRepository
) {

    suspend fun exportBackup(targetUri: Uri): BackupResult = withContext(Dispatchers.IO) {
        try {
            val tasks = repository.getAllTasksSnapshot()
            val notes = repository.getAllNotesSnapshot()
            val alarms = repository.getAllAlarmsSnapshot()
            val categories = repository.getAllCategoriesSnapshot()

            val rootJson = JSONObject().apply {
                put("app", "CHRONO")
                put("version", 1)
                put("exportedAt", System.currentTimeMillis())

                val tasksArray = JSONArray()
                for (t in tasks) {
                    tasksArray.put(
                        JSONObject().apply {
                            put("id", t.id)
                            put("title", t.title)
                            put("description", t.description)
                            put("dueDateEpochDay", t.dueDateEpochDay ?: -1L)
                            put("dueTimeMinutes", t.dueTimeMinutes ?: -1)
                            put("priority", t.priority.name)
                            put("categoryId", t.categoryId)
                            put("isCompleted", t.isCompleted)
                            put("completedAtMillis", t.completedAtMillis ?: -1L)
                            put("hasReminder", t.hasReminder)
                            put("createdAtMillis", t.createdAtMillis)
                        }
                    )
                }
                put("tasks", tasksArray)

                val notesArray = JSONArray()
                for (n in notes) {
                    notesArray.put(
                        JSONObject().apply {
                            put("id", n.id)
                            put("title", n.title)
                            put("content", n.content)
                            put("isPinned", n.isPinned)
                            put("colorTag", n.colorTag)
                            put("createdAtMillis", n.createdAtMillis)
                            put("updatedAtMillis", n.updatedAtMillis)
                        }
                    )
                }
                put("notes", notesArray)

                val alarmsArray = JSONArray()
                for (a in alarms) {
                    alarmsArray.put(
                        JSONObject().apply {
                            put("id", a.id)
                            put("label", a.label)
                            put("hour", a.hour)
                            put("minute", a.minute)
                            put("isEnabled", a.isEnabled)
                            put("recurringDays", a.recurringDays)
                            put("ringtoneUri", a.ringtoneUri ?: "")
                            put("vibrate", a.vibrate)
                            put("createdAtMillis", a.createdAtMillis)
                        }
                    )
                }
                put("alarms", alarmsArray)

                val categoriesArray = JSONArray()
                for (c in categories) {
                    categoriesArray.put(
                        JSONObject().apply {
                            put("id", c.id)
                            put("name", c.name)
                            put("iconName", c.iconName)
                            put("colorHex", c.colorHex)
                        }
                    )
                }
                put("categories", categoriesArray)
            }

            context.contentResolver.openOutputStream(targetUri)?.use { stream ->
                stream.write(rootJson.toString(2).toByteArray(Charsets.UTF_8))
                stream.flush()
            } ?: return@withContext BackupResult(false, errorMessage = "Cannot open output stream")

            BackupResult(
                success = true,
                tasksCount = tasks.size,
                notesCount = notes.size,
                alarmsCount = alarms.size,
                categoriesCount = categories.size
            )
        } catch (e: Exception) {
            BackupResult(false, errorMessage = e.localizedMessage ?: "Unknown export error")
        }
    }

    suspend fun importBackup(sourceUri: Uri): BackupResult = withContext(Dispatchers.IO) {
        try {
            val content = context.contentResolver.openInputStream(sourceUri)?.use { stream ->
                stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } ?: return@withContext BackupResult(false, errorMessage = "Cannot open input stream")

            val rootJson = JSONObject(content)
            if (!rootJson.has("app") || rootJson.getString("app") != "CHRONO") {
                return@withContext BackupResult(false, errorMessage = "Selected file is not a valid CHRONO backup file")
            }

            val tasksList = mutableListOf<TaskEntity>()
            val tasksArray = rootJson.optJSONArray("tasks")
            if (tasksArray != null) {
                for (i in 0 until tasksArray.length()) {
                    val obj = tasksArray.getJSONObject(i)
                    val epochDay = obj.optLong("dueDateEpochDay", -1L)
                    val dueTime = obj.optInt("dueTimeMinutes", -1)
                    val completedAt = obj.optLong("completedAtMillis", -1L)
                    tasksList.add(
                        TaskEntity(
                            id = 0L, // Generate fresh IDs to prevent collision
                            title = obj.getString("title"),
                            description = obj.optString("description", ""),
                            dueDateEpochDay = if (epochDay >= 0) epochDay else null,
                            dueTimeMinutes = if (dueTime >= 0) dueTime else null,
                            priority = com.example.data.model.TaskPriority.fromString(obj.optString("priority", "MEDIUM")),
                            categoryId = obj.optString("categoryId", "general"),
                            isCompleted = obj.optBoolean("isCompleted", false),
                            completedAtMillis = if (completedAt >= 0) completedAt else null,
                            hasReminder = obj.optBoolean("hasReminder", false),
                            createdAtMillis = obj.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }
            }

            val notesList = mutableListOf<NoteEntity>()
            val notesArray = rootJson.optJSONArray("notes")
            if (notesArray != null) {
                for (i in 0 until notesArray.length()) {
                    val obj = notesArray.getJSONObject(i)
                    notesList.add(
                        NoteEntity(
                            id = 0L,
                            title = obj.getString("title"),
                            content = obj.optString("content", ""),
                            isPinned = obj.optBoolean("isPinned", false),
                            colorTag = obj.optString("colorTag", "default"),
                            createdAtMillis = obj.optLong("createdAtMillis", System.currentTimeMillis()),
                            updatedAtMillis = obj.optLong("updatedAtMillis", System.currentTimeMillis())
                        )
                    )
                }
            }

            val alarmsList = mutableListOf<AlarmEntity>()
            val alarmsArray = rootJson.optJSONArray("alarms")
            if (alarmsArray != null) {
                for (i in 0 until alarmsArray.length()) {
                    val obj = alarmsArray.getJSONObject(i)
                    val ringtone = obj.optString("ringtoneUri", "")
                    alarmsList.add(
                        AlarmEntity(
                            id = 0L,
                            label = obj.optString("label", "Alarm"),
                            hour = obj.getInt("hour"),
                            minute = obj.getInt("minute"),
                            isEnabled = obj.optBoolean("isEnabled", true),
                            recurringDays = obj.optString("recurringDays", ""),
                            ringtoneUri = if (ringtone.isNotBlank()) ringtone else null,
                            vibrate = obj.optBoolean("vibrate", true),
                            createdAtMillis = obj.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }
            }

            val categoriesList = mutableListOf<CategoryEntity>()
            val categoriesArray = rootJson.optJSONArray("categories")
            if (categoriesArray != null) {
                for (i in 0 until categoriesArray.length()) {
                    val obj = categoriesArray.getJSONObject(i)
                    categoriesList.add(
                        CategoryEntity(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            iconName = obj.optString("iconName", "folder"),
                            colorHex = obj.optString("colorHex", "#8B5CF6")
                        )
                    )
                }
            }

            repository.restoreDatabase(
                tasks = tasksList,
                notes = notesList,
                alarms = alarmsList,
                categories = categoriesList
            )

            BackupResult(
                success = true,
                tasksCount = tasksList.size,
                notesCount = notesList.size,
                alarmsCount = alarmsList.size,
                categoriesCount = categoriesList.size
            )
        } catch (e: Exception) {
            BackupResult(false, errorMessage = e.localizedMessage ?: "Failed to import backup")
        }
    }
}
