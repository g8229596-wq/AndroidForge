package com.example.ui.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.NoteEntity
import com.example.data.repository.ChronoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class NotesUiState(
    val notes: List<NoteEntity> = emptyList(),
    val searchQuery: String = "",
    val editingNote: NoteEntity? = null
)

class NotesViewModel(
    private val repository: ChronoRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _editingNote = MutableStateFlow<NoteEntity?>(null)

    val editingNote: StateFlow<NoteEntity?> = _editingNote.asStateFlow()

    val uiState: StateFlow<NotesUiState> = combine(
        repository.allNotes,
        _searchQuery
    ) { allNotes, query ->
        val filtered = if (query.isBlank()) {
            allNotes
        } else {
            allNotes.filter {
                it.title.contains(query, ignoreCase = true) ||
                    it.content.contains(query, ignoreCase = true)
            }
        }
        NotesUiState(
            notes = filtered,
            searchQuery = query
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        NotesUiState()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setEditingNote(note: NoteEntity?) {
        _editingNote.value = note
    }

    fun togglePin(note: NoteEntity) {
        viewModelScope.launch {
            repository.toggleNotePin(note.id, !note.isPinned)
        }
    }

    fun saveNote(id: Long, title: String, content: String, isPinned: Boolean) {
        viewModelScope.launch {
            val note = NoteEntity(
                id = id,
                title = title.trim(),
                content = content.trim(),
                isPinned = isPinned,
                updatedAtMillis = System.currentTimeMillis()
            )
            if (id == 0L) {
                repository.insertNote(note)
            } else {
                repository.updateNote(note)
            }
            _editingNote.value = null
        }
    }

    fun deleteNote(noteId: Long) {
        viewModelScope.launch {
            repository.deleteNoteById(noteId)
        }
    }

    companion object {
        fun provideFactory(repository: ChronoRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return NotesViewModel(repository) as T
                }
            }
    }
}
