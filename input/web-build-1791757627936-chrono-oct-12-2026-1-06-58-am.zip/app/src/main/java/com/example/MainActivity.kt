package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.alarms.AlarmsScreen
import com.example.ui.alarms.AlarmsViewModel
import com.example.ui.components.ChronoBottomNav
import com.example.ui.components.MiniPlayerBar
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.dashboard.DashboardViewModel
import com.example.ui.music.MusicScreen
import com.example.ui.music.MusicViewModel
import com.example.ui.music.NowPlayingSheet
import com.example.ui.navigation.Screen
import com.example.ui.notes.NotesScreen
import com.example.ui.notes.NotesViewModel
import com.example.ui.planner.PlannerScreen
import com.example.ui.planner.PlannerViewModel
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel
import com.example.ui.theme.ChronoTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as ChronoApplication

        setContent {
            val settingsViewModel: SettingsViewModel = viewModel(
                factory = SettingsViewModel.provideFactory(
                    this,
                    app.preferencesRepository,
                    app.backupManager,
                    app.repository,
                    app.alarmScheduler
                )
            )

            val preferences by settingsViewModel.userPreferences.collectAsState()

            ChronoTheme(
                themeMode = preferences.themeMode,
                accent = preferences.accentOption
            ) {
                MainAppContent(app = app, settingsViewModel = settingsViewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(
    app: ChronoApplication,
    settingsViewModel: SettingsViewModel
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val navController = rememberNavController()

    // Request Notification permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Permission result handled */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val isGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!isGranted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val dashboardViewModel: DashboardViewModel = viewModel(
        factory = DashboardViewModel.provideFactory(app.repository, app.alarmScheduler)
    )
    val plannerViewModel: PlannerViewModel = viewModel(
        factory = PlannerViewModel.provideFactory(app.repository, app.alarmScheduler)
    )
    val notesViewModel: NotesViewModel = viewModel(
        factory = NotesViewModel.provideFactory(app.repository)
    )
    val alarmsViewModel: AlarmsViewModel = viewModel(
        factory = AlarmsViewModel.provideFactory(context, app.repository, app.alarmScheduler)
    )
    val musicViewModel: MusicViewModel = viewModel(
        factory = MusicViewModel.provideFactory(
            app.audioScanner,
            app.musicController,
            app.preferencesRepository
        )
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Dashboard.route

    val musicPlayerState by musicViewModel.playerState.collectAsState()
    val musicUiState by musicViewModel.uiState.collectAsState()
    var showNowPlayingExpanded by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            Column {
                // Mini Player Bar above the bottom navigation
                MiniPlayerBar(
                    currentSong = musicPlayerState.currentSong,
                    isPlaying = musicPlayerState.isPlaying,
                    progressMs = musicPlayerState.currentPositionMs,
                    durationMs = musicPlayerState.durationMs,
                    onTogglePlayPause = { musicViewModel.togglePlayPause() },
                    onSkipNext = { musicViewModel.skipNext() },
                    onClick = { showNowPlayingExpanded = true }
                )

                // Bottom Navigation Bar (Hidden when inside notes sub-screen)
                if (currentRoute != Screen.Notes.route) {
                    ChronoBottomNav(
                        currentRoute = currentRoute,
                        onNavigate = { screen ->
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(Screen.Dashboard.route) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Dashboard.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(Screen.Dashboard.route) {
                    DashboardScreen(
                        viewModel = dashboardViewModel,
                        onNavigate = { screen -> navController.navigate(screen.route) }
                    )
                }

                composable(Screen.Planner.route) {
                    PlannerScreen(viewModel = plannerViewModel)
                }

                composable(Screen.Alarms.route) {
                    AlarmsScreen(viewModel = alarmsViewModel)
                }

                composable(Screen.Music.route) {
                    MusicScreen(viewModel = musicViewModel)
                }

                composable(Screen.Settings.route) {
                    SettingsScreen(viewModel = settingsViewModel)
                }

                composable(Screen.Notes.route) {
                    NotesScreen(
                        viewModel = notesViewModel,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }

    // Now Playing Expanded Modal Sheet
    if (showNowPlayingExpanded && musicPlayerState.currentSong != null) {
        val currentSongId = musicPlayerState.currentSong?.id ?: 0L
        NowPlayingSheet(
            state = musicPlayerState,
            isFavorite = musicUiState.favoriteIds.contains(currentSongId),
            onToggleFavorite = { musicViewModel.toggleFavorite(it) },
            onTogglePlayPause = { musicViewModel.togglePlayPause() },
            onSkipNext = { musicViewModel.skipNext() },
            onSkipPrevious = { musicViewModel.skipPrevious() },
            onSeekTo = { musicViewModel.seekTo(it) },
            onToggleShuffle = { musicViewModel.toggleShuffle() },
            onCycleRepeat = { musicViewModel.cycleRepeat() },
            onPlayQueueIndex = { musicViewModel.playQueueIndex(it) },
            onDismiss = { showNowPlayingExpanded = false }
        )
    }
}
