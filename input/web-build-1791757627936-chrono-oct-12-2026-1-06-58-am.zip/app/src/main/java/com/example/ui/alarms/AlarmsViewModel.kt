package com.example.ui.alarms

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AlarmEntity
import com.example.data.repository.ChronoRepository
import com.example.domain.alarm.AlarmScheduler
import com.example.receiver.AlarmReceiver
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class TimerState(
    val selectedHours: Int = 0,
    val selectedMinutes: Int = 5,
    val selectedSeconds: Int = 0,
    val remainingMillis: Long = 5 * 60 * 1000L,
    val totalMillis: Long = 5 * 60 * 1000L,
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val isFinished: Boolean = false,
    val vibrateEnabled: Boolean = true
) {
    val progress: Float
        get() = if (totalMillis > 0) (remainingMillis.toFloat() / totalMillis.toFloat()).coerceIn(0f, 1f) else 0f

    val formattedRemaining: String
        get() {
            val totalSec = (remainingMillis / 1000).coerceAtLeast(0)
            val h = totalSec / 3600
            val m = (totalSec % 3600) / 60
            val s = totalSec % 60
            return if (h > 0) {
                String.format("%02d:%02d:%02d", h, m, s)
            } else {
                String.format("%02d:%02d", m, s)
            }
        }
}

data class AlarmsUiState(
    val alarms: List<AlarmEntity> = emptyList(),
    val nextAlarmInfo: String? = null,
    val editingAlarm: AlarmEntity? = null,
    val timerState: TimerState = TimerState()
)

class AlarmsViewModel(
    private val context: Context,
    private val repository: ChronoRepository,
    private val alarmScheduler: AlarmScheduler
) : ViewModel() {

    private val _editingAlarm = MutableStateFlow<AlarmEntity?>(null)
    private val _timerState = MutableStateFlow(TimerState())
    private var timerJob: Job? = null

    val editingAlarm: StateFlow<AlarmEntity?> = _editingAlarm.asStateFlow()

    val uiState: StateFlow<AlarmsUiState> = combine(
        repository.allAlarms,
        _editingAlarm,
        _timerState
    ) { alarms, editing, timer ->
        val activeAlarms = alarms.filter { it.isEnabled }
        val nextAlarmText = if (activeAlarms.isNotEmpty()) {
            val now = System.currentTimeMillis()
            val nextAlarm = activeAlarms.minByOrNull { alarm ->
                AlarmScheduler.calculateNextTriggerMillis(
                    alarm.hour,
                    alarm.minute,
                    alarm.getDaysSet(),
                    now
                )
            }
            if (nextAlarm != null) {
                val nextMillis = AlarmScheduler.calculateNextTriggerMillis(
                    nextAlarm.hour,
                    nextAlarm.minute,
                    nextAlarm.getDaysSet(),
                    now
                )
                val diffHours = ((nextMillis - now) / (1000 * 60 * 60)).coerceAtLeast(0)
                val diffMins = (((nextMillis - now) / (1000 * 60)) % 60).coerceAtLeast(0)
                "Next alarm: ${String.format("%02d:%02d", nextAlarm.hour, nextAlarm.minute)} (in ${diffHours}h ${diffMins}m)"
            } else null
        } else {
            "No active alarms scheduled"
        }

        AlarmsUiState(
            alarms = alarms,
            nextAlarmInfo = nextAlarmText,
            editingAlarm = editing,
            timerState = timer
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        AlarmsUiState()
    )

    fun setEditingAlarm(alarm: AlarmEntity?) {
        _editingAlarm.value = alarm
    }

    fun toggleAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            val newStatus = !alarm.isEnabled
            repository.setAlarmEnabled(alarm.id, newStatus)
            if (newStatus) {
                alarmScheduler.scheduleAlarm(alarm.copy(isEnabled = true))
            } else {
                alarmScheduler.cancelAlarm(alarm.id)
            }
        }
    }

    fun saveAlarm(
        id: Long,
        label: String,
        hour: Int,
        minute: Int,
        isEnabled: Boolean,
        recurringDays: String,
        ringtoneUri: String?,
        vibrate: Boolean
    ) {
        viewModelScope.launch {
            val alarm = AlarmEntity(
                id = id,
                label = label.ifBlank { "Alarm" },
                hour = hour,
                minute = minute,
                isEnabled = isEnabled,
                recurringDays = recurringDays,
                ringtoneUri = ringtoneUri,
                vibrate = vibrate
            )

            if (id == 0L) {
                val newId = repository.insertAlarm(alarm)
                if (isEnabled) {
                    alarmScheduler.scheduleAlarm(alarm.copy(id = newId))
                }
            } else {
                repository.updateAlarm(alarm)
                if (isEnabled) {
                    alarmScheduler.scheduleAlarm(alarm)
                } else {
                    alarmScheduler.cancelAlarm(id)
                }
            }
            _editingAlarm.value = null
        }
    }

    fun deleteAlarm(alarmId: Long) {
        viewModelScope.launch {
            alarmScheduler.cancelAlarm(alarmId)
            repository.deleteAlarmById(alarmId)
        }
    }

    // Timer Controls
    fun setTimerDuration(hours: Int, minutes: Int, seconds: Int) {
        val total = (hours * 3600 + minutes * 60 + seconds) * 1000L
        _timerState.update {
            it.copy(
                selectedHours = hours,
                selectedMinutes = minutes,
                selectedSeconds = seconds,
                remainingMillis = total,
                totalMillis = total,
                isRunning = false,
                isPaused = false,
                isFinished = false
            )
        }
    }

    fun setTimerVibrate(enabled: Boolean) {
        _timerState.update { it.copy(vibrateEnabled = enabled) }
    }

    fun startTimer() {
        val total = _timerState.value.totalMillis
        if (total <= 0L) return

        _timerState.update { it.copy(isRunning = true, isPaused = false, isFinished = false) }
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive && _timerState.value.remainingMillis > 0) {
                delay(100)
                _timerState.update {
                    val next = (it.remainingMillis - 100).coerceAtLeast(0L)
                    it.copy(remainingMillis = next)
                }
            }
            if (_timerState.value.remainingMillis <= 0L) {
                onTimerFinished()
            }
        }
    }

    fun pauseTimer() {
        timerJob?.cancel()
        _timerState.update { it.copy(isRunning = false, isPaused = true) }
    }

    fun resumeTimer() {
        startTimer()
    }

    fun resetTimer() {
        timerJob?.cancel()
        val total = _timerState.value.totalMillis
        _timerState.update {
            it.copy(
                remainingMillis = total,
                isRunning = false,
                isPaused = false,
                isFinished = false
            )
        }
        stopTimerSound()
    }

    private fun onTimerFinished() {
        _timerState.update { it.copy(isRunning = false, isPaused = false, isFinished = true) }
        // Trigger timer finished alert
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_TIMER
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, "Timer is complete!")
            putExtra(AlarmReceiver.EXTRA_VIBRATE, _timerState.value.vibrateEnabled)
        }
        context.sendBroadcast(intent)
    }

    fun stopTimerSound() {
        AlarmReceiver.stopActiveRingtone()
        _timerState.update { it.copy(isFinished = false) }
    }

    override fun onCleared() {
        timerJob?.cancel()
        super.onCleared()
    }

    companion object {
        fun provideFactory(
            context: Context,
            repository: ChronoRepository,
            alarmScheduler: AlarmScheduler
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return AlarmsViewModel(context.applicationContext, repository, alarmScheduler) as T
            }
        }
    }
}
