package com.example.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.model.Song
import com.example.service.ChronoMediaPlaybackService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class MusicPlayerState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isShuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF, // 0=OFF, 1=ONE, 2=ALL
    val queue: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val isConnected: Boolean = false
)

class MusicController private constructor(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var positionJob: Job? = null

    private var mediaController: MediaController? = null
    private val _state = MutableStateFlow(MusicPlayerState())
    val state: StateFlow<MusicPlayerState> = _state.asStateFlow()

    init {
        initializeMediaController()
    }

    private fun initializeMediaController() {
        try {
            val sessionToken = SessionToken(
                context,
                ComponentName(context, ChronoMediaPlaybackService::class.java)
            )
            val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
            controllerFuture.addListener({
                try {
                    val controller = controllerFuture.get()
                    mediaController = controller
                    setupPlayerListener(controller)
                    _state.update { it.copy(isConnected = true) }
                    Log.d("MusicController", "Connected to ChronoMediaPlaybackService successfully")
                } catch (e: Exception) {
                    Log.e("MusicController", "Failed to get MediaController: ${e.message}")
                }
            }, ContextCompat.getMainExecutor(context))
        } catch (e: Exception) {
            Log.e("MusicController", "Error initializing MediaController: ${e.message}")
        }
    }

    private fun setupPlayerListener(player: Player) {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _state.update { it.copy(isPlaying = isPlaying) }
                if (isPlaying) {
                    startPositionUpdates()
                } else {
                    stopPositionUpdates()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    val duration = player.duration.coerceAtLeast(0L)
                    _state.update { it.copy(durationMs = duration) }
                } else if (playbackState == Player.STATE_ENDED) {
                    onSongEnded()
                }
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                _state.update { it.copy(isShuffle = shuffleModeEnabled) }
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                _state.update { it.copy(repeatMode = repeatMode) }
            }
        })
    }

    private fun startPositionUpdates() {
        stopPositionUpdates()
        positionJob = scope.launch {
            while (isActive) {
                mediaController?.let { controller ->
                    val pos = controller.currentPosition.coerceAtLeast(0L)
                    val dur = controller.duration.coerceAtLeast(0L)
                    _state.update { it.copy(currentPositionMs = pos, durationMs = dur) }
                }
                delay(500)
            }
        }
    }

    private fun stopPositionUpdates() {
        positionJob?.cancel()
        positionJob = null
    }

    fun playQueue(songs: List<Song>, startIndex: Int) {
        if (songs.isEmpty() || startIndex !in songs.indices) return

        val targetSong = songs[startIndex]
        _state.update {
            it.copy(
                queue = songs,
                currentIndex = startIndex,
                currentSong = targetSong
            )
        }

        mediaController?.let { controller ->
            val mediaItems = songs.map { song ->
                MediaItem.Builder()
                    .setMediaId(song.id.toString())
                    .setUri(song.contentUri)
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(song.title)
                            .setArtist(song.artist)
                            .setAlbumTitle(song.album)
                            .setArtworkUri(song.albumArtUri)
                            .build()
                    )
                    .build()
            }
            controller.setMediaItems(mediaItems, startIndex, 0L)
            controller.prepare()
            controller.play()
        }
    }

    fun playSong(song: Song) {
        val currentQueue = _state.value.queue
        val existingIndex = currentQueue.indexOfFirst { it.id == song.id }
        if (existingIndex != -1) {
            playQueue(currentQueue, existingIndex)
        } else {
            val newQueue = listOf(song) + currentQueue
            playQueue(newQueue, 0)
        }
    }

    fun togglePlayPause() {
        mediaController?.let { controller ->
            if (controller.isPlaying) {
                controller.pause()
            } else {
                if (controller.playbackState == Player.STATE_IDLE && _state.value.currentSong != null) {
                    playSong(_state.value.currentSong!!)
                } else {
                    controller.play()
                }
            }
        }
    }

    fun skipToNext() {
        val s = _state.value
        if (s.queue.isEmpty()) return

        if (s.isShuffle && s.queue.size > 1) {
            val nextIndex = (s.queue.indices.filter { it != s.currentIndex }).random()
            playQueue(s.queue, nextIndex)
            return
        }

        val nextIndex = s.currentIndex + 1
        if (nextIndex in s.queue.indices) {
            playQueue(s.queue, nextIndex)
        } else if (s.repeatMode == Player.REPEAT_MODE_ALL) {
            playQueue(s.queue, 0)
        }
    }

    fun skipToPrevious() {
        val s = _state.value
        if (s.queue.isEmpty()) return

        // If played more than 3 seconds, restart current track
        val currentPos = mediaController?.currentPosition ?: 0L
        if (currentPos > 3000L) {
            seekTo(0L)
            return
        }

        val prevIndex = s.currentIndex - 1
        if (prevIndex >= 0) {
            playQueue(s.queue, prevIndex)
        } else if (s.repeatMode == Player.REPEAT_MODE_ALL) {
            playQueue(s.queue, s.queue.lastIndex)
        }
    }

    fun seekTo(positionMs: Long) {
        mediaController?.seekTo(positionMs)
        _state.update { it.copy(currentPositionMs = positionMs) }
    }

    fun toggleShuffle() {
        val newShuffle = !_state.value.isShuffle
        mediaController?.shuffleModeEnabled = newShuffle
        _state.update { it.copy(isShuffle = newShuffle) }
    }

    fun cycleRepeatMode() {
        val nextMode = when (_state.value.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        mediaController?.repeatMode = nextMode
        _state.update { it.copy(repeatMode = nextMode) }
    }

    private fun onSongEnded() {
        val s = _state.value
        if (s.repeatMode == Player.REPEAT_MODE_ONE) {
            seekTo(0L)
            mediaController?.play()
        } else {
            skipToNext()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: MusicController? = null

        fun getInstance(context: Context): MusicController {
            return INSTANCE ?: synchronized(this) {
                val instance = MusicController(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
