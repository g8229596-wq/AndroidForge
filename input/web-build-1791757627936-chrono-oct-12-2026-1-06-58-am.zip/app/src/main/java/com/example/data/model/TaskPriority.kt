package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.ChronoAmber
import com.example.ui.theme.ChronoEmerald
import com.example.ui.theme.ChronoRose

enum class TaskPriority(val displayName: String, val color: Color) {
    LOW("Low", ChronoEmerald),
    MEDIUM("Medium", ChronoAmber),
    HIGH("High", ChronoRose);

    companion object {
        fun fromString(value: String?): TaskPriority {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: MEDIUM
        }
    }
}
