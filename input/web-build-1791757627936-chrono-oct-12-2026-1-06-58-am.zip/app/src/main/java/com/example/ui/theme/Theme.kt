package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AccentOption(val displayName: String, val primaryColor: Color, val lightColor: Color) {
    VIOLET("Electric Violet", ChronoViolet, ChronoVioletLight),
    EMERALD("Emerald Neon", ChronoEmerald, ChronoEmeraldLight),
    ROSE("Rose Quartz", ChronoRose, ChronoRoseLight),
    CYAN("Cyber Cyan", ChronoCyan, ChronoCyanLight),
    AMBER("Amber Glow", ChronoAmber, ChronoAmberLight)
}

enum class ThemeMode {
    DARK,
    LIGHT,
    SYSTEM
}

fun createChronoDarkColorScheme(accent: AccentOption): androidx.compose.material3.ColorScheme {
    return darkColorScheme(
        primary = accent.primaryColor,
        onPrimary = Color.White,
        primaryContainer = accent.primaryColor.copy(alpha = 0.2f),
        onPrimaryContainer = accent.lightColor,
        secondary = accent.lightColor,
        onSecondary = Color.Black,
        secondaryContainer = accent.primaryColor.copy(alpha = 0.15f),
        onSecondaryContainer = accent.lightColor,
        tertiary = ChronoCyan,
        onTertiary = Color.Black,
        background = ChronoBackgroundDark,
        onBackground = ChronoTextPrimaryDark,
        surface = ChronoSurfaceDark,
        onSurface = ChronoTextPrimaryDark,
        surfaceVariant = ChronoSurfaceVariantDark,
        onSurfaceVariant = ChronoTextSecondaryDark,
        outline = ChronoBorderDark,
        outlineVariant = ChronoBorderDark.copy(alpha = 0.5f),
        error = ChronoRose,
        onError = Color.White
    )
}

fun createChronoLightColorScheme(accent: AccentOption): androidx.compose.material3.ColorScheme {
    return lightColorScheme(
        primary = accent.primaryColor,
        onPrimary = Color.White,
        primaryContainer = accent.primaryColor.copy(alpha = 0.12f),
        onPrimaryContainer = accent.primaryColor,
        secondary = accent.lightColor,
        onSecondary = Color.White,
        secondaryContainer = accent.primaryColor.copy(alpha = 0.08f),
        onSecondaryContainer = accent.primaryColor,
        tertiary = ChronoCyan,
        onTertiary = Color.White,
        background = ChronoBackgroundLight,
        onBackground = ChronoTextPrimaryLight,
        surface = ChronoSurfaceLight,
        onSurface = ChronoTextPrimaryLight,
        surfaceVariant = ChronoSurfaceVariantLight,
        onSurfaceVariant = ChronoTextSecondaryLight,
        outline = ChronoBorderLight,
        outlineVariant = ChronoBorderLight.copy(alpha = 0.6f),
        error = ChronoRose,
        onError = Color.White
    )
}

@Composable
fun ChronoTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    accent: AccentOption = AccentOption.VIOLET,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) {
        createChronoDarkColorScheme(accent)
    } else {
        createChronoLightColorScheme(accent)
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
