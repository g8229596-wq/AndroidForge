package com.example.ui.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.backup.BackupManager
import com.example.data.backup.BackupResult
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.ChronoRepository
import com.example.domain.alarm.AlarmScheduler
import com.example.ui.theme.AccentOption
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DatabaseStats(
    val tasksCount: Int = 0,
    val notesCount: Int = 0,
    val alarmsCount: Int = 0
)

class SettingsViewModel(
    private val context: Context,
    private val preferencesRepository: UserPreferencesRepository,
    private val backupManager: BackupManager,
    private val repository: ChronoRepository,
    private val alarmScheduler: AlarmScheduler
) : ViewModel() {

    val userPreferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    private val _databaseStats = MutableStateFlow(DatabaseStats())
    val databaseStats: StateFlow<DatabaseStats> = _databaseStats.asStateFlow()

    private val _backupStatusMessage = MutableStateFlow<String?>(null)
    val backupStatusMessage: StateFlow<String?> = _backupStatusMessage.asStateFlow()

    init {
        refreshStats()
    }

    fun refreshStats() {
        viewModelScope.launch {
            val tasks = repository.getAllTasksSnapshot().size
            val notes = repository.getAllNotesSnapshot().size
            val alarms = repository.getAllAlarmsSnapshot().size
            _databaseStats.value = DatabaseStats(tasks, notes, alarms)
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun setAccent(accent: AccentOption) {
        viewModelScope.launch {
            preferencesRepository.setAccentOption(accent)
        }
    }

    fun setVibrate(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setVibrateOnAlarm(enabled)
        }
    }

    fun canScheduleExactAlarms(): Boolean = alarmScheduler.canScheduleExactAlarms()

    fun exportBackup(targetUri: Uri) {
        viewModelScope.launch {
            val res = backupManager.exportBackup(targetUri)
            if (res.success) {
                _backupStatusMessage.value = "Backup exported successfully: ${res.tasksCount} tasks, ${res.notesCount} notes, ${res.alarmsCount} alarms."
            } else {
                _backupStatusMessage.value = "Export failed: ${res.errorMessage}"
            }
            refreshStats()
        }
    }

    fun importBackup(sourceUri: Uri) {
        viewModelScope.launch {
            val res = backupManager.importBackup(sourceUri)
            if (res.success) {
                _backupStatusMessage.value = "Backup restored successfully: ${res.tasksCount} tasks, ${res.notesCount} notes, ${res.alarmsCount} alarms."
            } else {
                _backupStatusMessage.value = "Restore failed: ${res.errorMessage}"
            }
            refreshStats()
        }
    }

    fun clearStatusMessage() {
        _backupStatusMessage.value = null
    }

    companion object {
        fun provideFactory(
            context: Context,
            preferencesRepository: UserPreferencesRepository,
            backupManager: BackupManager,
            repository: ChronoRepository,
            alarmScheduler: AlarmScheduler
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return SettingsViewModel(
                    context.applicationContext,
                    preferencesRepository,
                    backupManager,
                    repository,
                    alarmScheduler
                ) as T
            }
        }
    }
}
