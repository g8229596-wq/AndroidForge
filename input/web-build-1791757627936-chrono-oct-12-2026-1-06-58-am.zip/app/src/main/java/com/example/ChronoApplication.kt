package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.data.backup.BackupManager
import com.example.data.local.ChronoDatabase
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.ChronoRepository
import com.example.domain.alarm.AlarmScheduler
import com.example.player.AudioScanner
import com.example.player.MusicController
import com.example.receiver.AlarmReceiver

class ChronoApplication : Application() {

    lateinit var database: ChronoDatabase
        private set

    lateinit var repository: ChronoRepository
        private set

    lateinit var preferencesRepository: UserPreferencesRepository
        private set

    lateinit var alarmScheduler: AlarmScheduler
        private set

    lateinit var backupManager: BackupManager
        private set

    lateinit var audioScanner: AudioScanner
        private set

    lateinit var musicController: MusicController
        private set

    override fun onCreate() {
        super.onCreate()

        database = ChronoDatabase.getDatabase(this)
        repository = ChronoRepository(
            database.taskDao(),
            database.noteDao(),
            database.alarmDao(),
            database.categoryDao()
        )
        preferencesRepository = UserPreferencesRepository(this)
        alarmScheduler = AlarmScheduler(this)
        backupManager = BackupManager(this, repository)
        audioScanner = AudioScanner(this)
        musicController = MusicController.getInstance(this)

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            val alarmChannel = NotificationChannel(
                AlarmReceiver.CHANNEL_ALARMS,
                "CHRONO Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alarm alerts and ringing events"
                enableVibration(true)
            }

            val timerChannel = NotificationChannel(
                AlarmReceiver.CHANNEL_TIMERS,
                "CHRONO Timers",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Timer countdown completion alerts"
                enableVibration(true)
            }

            val reminderChannel = NotificationChannel(
                AlarmReceiver.CHANNEL_REMINDERS,
                "CHRONO Task Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Daily scheduled task reminders"
            }

            notificationManager.createNotificationChannel(alarmChannel)
            notificationManager.createNotificationChannel(timerChannel)
            notificationManager.createNotificationChannel(reminderChannel)
        }
    }
}
