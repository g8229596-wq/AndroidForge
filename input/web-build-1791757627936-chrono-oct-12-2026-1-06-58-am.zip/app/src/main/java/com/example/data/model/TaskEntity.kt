package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val description: String = "",
    val dueDateEpochDay: Long? = null,
    val dueTimeMinutes: Int? = null, // minute of day: 0..1439
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val categoryId: String = "general",
    val isCompleted: Boolean = false,
    val completedAtMillis: Long? = null,
    val hasReminder: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)
