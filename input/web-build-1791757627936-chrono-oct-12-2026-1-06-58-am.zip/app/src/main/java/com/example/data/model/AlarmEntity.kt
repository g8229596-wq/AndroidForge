package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val label: String = "Alarm",
    val hour: Int, // 0..23
    val minute: Int, // 0..59
    val isEnabled: Boolean = true,
    // Days of week: comma separated numbers 1..7 (1=Monday, 7=Sunday) or empty string for one-time
    val recurringDays: String = "",
    val ringtoneUri: String? = null,
    val vibrate: Boolean = true,
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    fun isRecurring(): Boolean = recurringDays.isNotBlank()

    fun getDaysSet(): Set<Int> {
        if (recurringDays.isBlank()) return emptySet()
        return recurringDays.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .toSet()
    }
}
