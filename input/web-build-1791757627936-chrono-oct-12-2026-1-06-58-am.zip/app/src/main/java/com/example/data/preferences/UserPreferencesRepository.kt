package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.AccentOption
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "chrono_preferences")

data class UserPreferences(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val accentOption: AccentOption = AccentOption.VIOLET,
    val vibrateOnAlarm: Boolean = true,
    val defaultRingtoneName: String = "Default Alarm Sound",
    val musicShuffle: Boolean = false,
    val musicRepeatMode: Int = 0, // 0 = OFF, 1 = ONE, 2 = ALL
    val lastPlayedSongId: Long? = null,
    val lastPlaybackPositionMs: Long = 0L,
    val favoriteSongIds: Set<Long> = emptySet()
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_OPTION = stringPreferencesKey("accent_option")
        val VIBRATE_ON_ALARM = booleanPreferencesKey("vibrate_on_alarm")
        val DEFAULT_RINGTONE_NAME = stringPreferencesKey("default_ringtone_name")
        val MUSIC_SHUFFLE = booleanPreferencesKey("music_shuffle")
        val MUSIC_REPEAT_MODE = intPreferencesKey("music_repeat_mode")
        val LAST_PLAYED_SONG_ID = longPreferencesKey("last_played_song_id")
        val LAST_PLAYBACK_POSITION = longPreferencesKey("last_playback_position")
        val FAVORITE_SONG_IDS = stringSetPreferencesKey("favorite_song_ids")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { preferences ->
        val themeModeStr = preferences[Keys.THEME_MODE] ?: ThemeMode.DARK.name
        val themeMode = runCatching { ThemeMode.valueOf(themeModeStr) }.getOrDefault(ThemeMode.DARK)

        val accentStr = preferences[Keys.ACCENT_OPTION] ?: AccentOption.VIOLET.name
        val accent = runCatching { AccentOption.valueOf(accentStr) }.getOrDefault(AccentOption.VIOLET)

        val vibrate = preferences[Keys.VIBRATE_ON_ALARM] ?: true
        val ringtone = preferences[Keys.DEFAULT_RINGTONE_NAME] ?: "Default Alarm Sound"
        val shuffle = preferences[Keys.MUSIC_SHUFFLE] ?: false
        val repeatMode = preferences[Keys.MUSIC_REPEAT_MODE] ?: 0
        val lastSongId = preferences[Keys.LAST_PLAYED_SONG_ID]
        val lastPosition = preferences[Keys.LAST_PLAYBACK_POSITION] ?: 0L
        val favIdsStrings = preferences[Keys.FAVORITE_SONG_IDS] ?: emptySet()
        val favIds = favIdsStrings.mapNotNull { it.toLongOrNull() }.toSet()

        UserPreferences(
            themeMode = themeMode,
            accentOption = accent,
            vibrateOnAlarm = vibrate,
            defaultRingtoneName = ringtone,
            musicShuffle = shuffle,
            musicRepeatMode = repeatMode,
            lastPlayedSongId = lastSongId,
            lastPlaybackPositionMs = lastPosition,
            favoriteSongIds = favIds
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setAccentOption(accent: AccentOption) {
        context.dataStore.edit { it[Keys.ACCENT_OPTION] = accent.name }
    }

    suspend fun setVibrateOnAlarm(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VIBRATE_ON_ALARM] = enabled }
    }

    suspend fun setDefaultRingtoneName(name: String) {
        context.dataStore.edit { it[Keys.DEFAULT_RINGTONE_NAME] = name }
    }

    suspend fun setMusicShuffle(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MUSIC_SHUFFLE] = enabled }
    }

    suspend fun setMusicRepeatMode(mode: Int) {
        context.dataStore.edit { it[Keys.MUSIC_REPEAT_MODE] = mode }
    }

    suspend fun setLastPlayback(songId: Long, positionMs: Long) {
        context.dataStore.edit {
            it[Keys.LAST_PLAYED_SONG_ID] = songId
            it[Keys.LAST_PLAYBACK_POSITION] = positionMs
        }
    }

    suspend fun toggleFavoriteSong(songId: Long) {
        context.dataStore.edit { prefs ->
            val current = (prefs[Keys.FAVORITE_SONG_IDS] ?: emptySet()).toMutableSet()
            val idStr = songId.toString()
            if (current.contains(idStr)) {
                current.remove(idStr)
            } else {
                current.add(idStr)
            }
            prefs[Keys.FAVORITE_SONG_IDS] = current
        }
    }
}
