package com.example.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AlarmEntity
import com.example.data.model.TaskEntity
import com.example.data.repository.ChronoRepository
import com.example.domain.alarm.AlarmScheduler
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

data class DashboardUiState(
    val greeting: String = "Hello",
    val formattedTime: String = "12:00",
    val formattedDate: String = "Monday, Oct 11",
    val todayTasks: List<TaskEntity> = emptyList(),
    val completedCount: Int = 0,
    val remainingCount: Int = 0,
    val progressPercent: Float = 0f,
    val activeAlarms: List<AlarmEntity> = emptyList()
)

class DashboardViewModel(
    private val repository: ChronoRepository,
    private val alarmScheduler: AlarmScheduler
) : ViewModel() {

    private val _clockTime = MutableStateFlow(getCurrentFormattedTime())
    val clockTime: StateFlow<String> = _clockTime.asStateFlow()

    private val currentEpochDay = LocalDate.now().toEpochDay()

    val uiState: StateFlow<DashboardUiState> = combine(
        _clockTime,
        repository.allTasks,
        repository.activeAlarms
    ) { time, allTasks, activeAlarms ->
        val today = LocalDate.now()
        val todayEpoch = today.toEpochDay()

        // Filter tasks that belong to today (or are past due and not completed)
        val todayTasks = allTasks.filter { task ->
            task.dueDateEpochDay == null || task.dueDateEpochDay <= todayEpoch
        }

        val completed = todayTasks.count { it.isCompleted }
        val remaining = todayTasks.size - completed
        val progress = if (todayTasks.isNotEmpty()) completed.toFloat() / todayTasks.size.toFloat() else 0f

        val greeting = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Good Morning"
            in 12..16 -> "Good Afternoon"
            in 17..21 -> "Good Evening"
            else -> "Night Owl"
        }

        val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
        val formattedDate = dateFormat.format(Date())

        DashboardUiState(
            greeting = greeting,
            formattedTime = time,
            formattedDate = formattedDate,
            todayTasks = todayTasks.take(5),
            completedCount = completed,
            remainingCount = remaining,
            progressPercent = progress,
            activeAlarms = activeAlarms.take(3)
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DashboardUiState()
    )

    init {
        startClockTicker()
    }

    private fun startClockTicker() {
        viewModelScope.launch {
            while (isActive) {
                _clockTime.value = getCurrentFormattedTime()
                delay(1000)
            }
        }
    }

    private fun getCurrentFormattedTime(): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        return sdf.format(Date())
    }

    fun toggleTaskComplete(task: TaskEntity) {
        viewModelScope.launch {
            repository.setTaskCompleted(task.id, !task.isCompleted)
        }
    }

    fun quickAddTask(title: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val task = TaskEntity(
                title = title.trim(),
                dueDateEpochDay = currentEpochDay,
                hasReminder = false
            )
            val id = repository.insertTask(task)
        }
    }

    companion object {
        fun provideFactory(
            repository: ChronoRepository,
            alarmScheduler: AlarmScheduler
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return DashboardViewModel(repository, alarmScheduler) as T
            }
        }
    }
}
