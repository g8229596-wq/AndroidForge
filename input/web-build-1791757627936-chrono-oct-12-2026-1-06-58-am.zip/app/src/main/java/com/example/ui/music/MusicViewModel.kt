package com.example.ui.music

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Song
import com.example.data.preferences.UserPreferencesRepository
import com.example.player.AudioScanner
import com.example.player.MusicController
import com.example.player.MusicPlayerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MusicUiState(
    val songs: List<Song> = emptyList(),
    val searchQuery: String = "",
    val showFavoritesOnly: Boolean = false,
    val favoriteIds: Set<Long> = emptySet(),
    val playerState: MusicPlayerState = MusicPlayerState(),
    val isLoading: Boolean = false
)

class MusicViewModel(
    private val audioScanner: AudioScanner,
    private val musicController: MusicController,
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _deviceSongs = MutableStateFlow<List<Song>>(emptyList())
    private val _searchQuery = MutableStateFlow("")
    private val _favoritesOnly = MutableStateFlow(false)
    private val _isLoading = MutableStateFlow(false)

    val playerState: StateFlow<MusicPlayerState> = musicController.state

    private data class MusicFilter(
        val query: String,
        val favoritesOnly: Boolean,
        val isLoading: Boolean
    )

    private val filterFlow = combine(
        _searchQuery,
        _favoritesOnly,
        _isLoading
    ) { query, favOnly, loading ->
        MusicFilter(query, favOnly, loading)
    }

    val uiState: StateFlow<MusicUiState> = combine(
        _deviceSongs,
        filterFlow,
        preferencesRepository.userPreferencesFlow,
        musicController.state
    ) { songs, filter, prefs, playerState ->
        val favoriteIds = prefs.favoriteSongIds

        val filtered = songs.filter { song ->
            val matchesQuery = filter.query.isBlank() ||
                song.title.contains(filter.query, ignoreCase = true) ||
                song.artist.contains(filter.query, ignoreCase = true) ||
                song.album.contains(filter.query, ignoreCase = true)

            val matchesFav = !filter.favoritesOnly || favoriteIds.contains(song.id)

            matchesQuery && matchesFav
        }

        MusicUiState(
            songs = filtered,
            searchQuery = filter.query,
            showFavoritesOnly = filter.favoritesOnly,
            favoriteIds = favoriteIds,
            playerState = playerState,
            isLoading = filter.isLoading
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MusicUiState()
    )

    init {
        loadDeviceSongs()
    }

    fun loadDeviceSongs() {
        viewModelScope.launch {
            _isLoading.value = true
            val scanned = audioScanner.queryDeviceAudio()
            _deviceSongs.value = scanned
            _isLoading.value = false
        }
    }

    fun addImportedUri(uri: Uri) {
        viewModelScope.launch {
            val song = audioScanner.parseFromUri(uri)
            if (song != null) {
                val current = _deviceSongs.value.toMutableList()
                if (current.none { it.id == song.id }) {
                    current.add(0, song)
                    _deviceSongs.value = current
                    // Auto play imported track
                    musicController.playSong(song)
                }
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFavoritesFilter() {
        _favoritesOnly.value = !_favoritesOnly.value
    }

    fun toggleFavorite(songId: Long) {
        viewModelScope.launch {
            preferencesRepository.toggleFavoriteSong(songId)
        }
    }

    fun playSong(song: Song) {
        val currentList = uiState.value.songs
        val index = currentList.indexOfFirst { it.id == song.id }
        if (index != -1) {
            musicController.playQueue(currentList, index)
        } else {
            musicController.playSong(song)
        }
    }

    fun playQueueIndex(index: Int) {
        musicController.playQueue(playerState.value.queue, index)
    }

    fun togglePlayPause() {
        musicController.togglePlayPause()
    }

    fun skipNext() {
        musicController.skipToNext()
    }

    fun skipPrevious() {
        musicController.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        musicController.seekTo(positionMs)
    }

    fun toggleShuffle() {
        musicController.toggleShuffle()
    }

    fun cycleRepeat() {
        musicController.cycleRepeatMode()
    }

    companion object {
        fun provideFactory(
            audioScanner: AudioScanner,
            musicController: MusicController,
            preferencesRepository: UserPreferencesRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return MusicViewModel(audioScanner, musicController, preferencesRepository) as T
            }
        }
    }
}
