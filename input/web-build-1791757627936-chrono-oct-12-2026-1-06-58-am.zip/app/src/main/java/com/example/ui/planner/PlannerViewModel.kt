package com.example.ui.planner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.CategoryEntity
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.data.repository.ChronoRepository
import com.example.domain.alarm.AlarmScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class DateFilter(val displayName: String) {
    TODAY("Today"),
    TOMORROW("Tomorrow"),
    UPCOMING("Upcoming"),
    ALL("All")
}

enum class TaskSort(val displayName: String) {
    TIME("Time"),
    PRIORITY("Priority")
}

data class PlannerUiState(
    val tasks: List<TaskEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val selectedCategory: String? = null,
    val selectedDateFilter: DateFilter = DateFilter.TODAY,
    val searchQuery: String = "",
    val sortMode: TaskSort = TaskSort.TIME,
    val selectedTaskForEdit: TaskEntity? = null
)

class PlannerViewModel(
    private val repository: ChronoRepository,
    private val alarmScheduler: AlarmScheduler
) : ViewModel() {

    private val _selectedCategory = MutableStateFlow<String?>(null)
    private val _selectedDateFilter = MutableStateFlow(DateFilter.TODAY)
    private val _searchQuery = MutableStateFlow("")
    private val _sortMode = MutableStateFlow(TaskSort.TIME)
    private val _editingTask = MutableStateFlow<TaskEntity?>(null)

    val editingTask: StateFlow<TaskEntity?> = _editingTask.asStateFlow()

    private data class PlannerFilter(
        val category: String?,
        val dateFilter: DateFilter,
        val query: String,
        val sortMode: TaskSort
    )

    private val filterFlow = combine(
        _selectedCategory,
        _selectedDateFilter,
        _searchQuery,
        _sortMode
    ) { category, dateFilter, query, sortMode ->
        PlannerFilter(category, dateFilter, query, sortMode)
    }

    val uiState: StateFlow<PlannerUiState> = combine(
        repository.allTasks,
        repository.allCategories,
        filterFlow
    ) { allTasks, categories, filter ->
        val todayEpoch = LocalDate.now().toEpochDay()
        val tomorrowEpoch = todayEpoch + 1

        val filteredTasks = allTasks.filter { task ->
            // Category filter
            val matchesCategory = filter.category == null || task.categoryId == filter.category

            // Date filter
            val matchesDate = when (filter.dateFilter) {
                DateFilter.TODAY -> task.dueDateEpochDay == null || task.dueDateEpochDay <= todayEpoch
                DateFilter.TOMORROW -> task.dueDateEpochDay == tomorrowEpoch
                DateFilter.UPCOMING -> task.dueDateEpochDay != null && task.dueDateEpochDay > todayEpoch
                DateFilter.ALL -> true
            }

            // Search query
            val matchesQuery = filter.query.isBlank() ||
                task.title.contains(filter.query, ignoreCase = true) ||
                task.description.contains(filter.query, ignoreCase = true)

            matchesCategory && matchesDate && matchesQuery
        }.sortedWith { a, b ->
            // Uncompleted first
            if (a.isCompleted != b.isCompleted) {
                return@sortedWith if (a.isCompleted) 1 else -1
            }
            if (filter.sortMode == TaskSort.PRIORITY) {
                val priorityDiff = b.priority.ordinal.compareTo(a.priority.ordinal)
                if (priorityDiff != 0) return@sortedWith priorityDiff
            }
            // Sort by due date & time
            val dateA = a.dueDateEpochDay ?: Long.MAX_VALUE
            val dateB = b.dueDateEpochDay ?: Long.MAX_VALUE
            val dateDiff = dateA.compareTo(dateB)
            if (dateDiff != 0) return@sortedWith dateDiff

            val timeA = a.dueTimeMinutes ?: 1440
            val timeB = b.dueTimeMinutes ?: 1440
            timeA.compareTo(timeB)
        }

        PlannerUiState(
            tasks = filteredTasks,
            categories = categories,
            selectedCategory = filter.category,
            selectedDateFilter = filter.dateFilter,
            searchQuery = filter.query,
            sortMode = filter.sortMode
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        PlannerUiState()
    )

    fun selectCategory(categoryId: String?) {
        _selectedCategory.value = categoryId
    }

    fun selectDateFilter(filter: DateFilter) {
        _selectedDateFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortMode(sort: TaskSort) {
        _sortMode.value = sort
    }

    fun setEditingTask(task: TaskEntity?) {
        _editingTask.value = task
    }

    fun toggleTaskComplete(task: TaskEntity) {
        viewModelScope.launch {
            repository.setTaskCompleted(task.id, !task.isCompleted)
        }
    }

    fun saveTask(
        id: Long,
        title: String,
        description: String,
        dueDateEpochDay: Long?,
        dueTimeMinutes: Int?,
        priority: TaskPriority,
        categoryId: String,
        hasReminder: Boolean
    ) {
        viewModelScope.launch {
            val task = TaskEntity(
                id = id,
                title = title.trim(),
                description = description.trim(),
                dueDateEpochDay = dueDateEpochDay,
                dueTimeMinutes = dueTimeMinutes,
                priority = priority,
                categoryId = categoryId,
                hasReminder = hasReminder
            )
            if (id == 0L) {
                val newId = repository.insertTask(task)
                if (hasReminder) {
                    alarmScheduler.scheduleTaskReminder(task.copy(id = newId))
                }
            } else {
                repository.updateTask(task)
                if (hasReminder) {
                    alarmScheduler.scheduleTaskReminder(task)
                } else {
                    alarmScheduler.cancelTaskReminder(id)
                }
            }
            _editingTask.value = null
        }
    }

    fun deleteTask(taskId: Long) {
        viewModelScope.launch {
            alarmScheduler.cancelTaskReminder(taskId)
            repository.deleteTaskById(taskId)
        }
    }

    companion object {
        fun provideFactory(
            repository: ChronoRepository,
            alarmScheduler: AlarmScheduler
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return PlannerViewModel(repository, alarmScheduler) as T
            }
        }
    }
}
