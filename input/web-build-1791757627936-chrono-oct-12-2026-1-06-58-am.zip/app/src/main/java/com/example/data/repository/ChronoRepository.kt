package com.example.data.repository

import com.example.data.local.AlarmDao
import com.example.data.local.CategoryDao
import com.example.data.local.NoteDao
import com.example.data.local.TaskDao
import com.example.data.model.AlarmEntity
import com.example.data.model.CategoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.TaskEntity
import kotlinx.coroutines.flow.Flow

class ChronoRepository(
    private val taskDao: TaskDao,
    private val noteDao: NoteDao,
    private val alarmDao: AlarmDao,
    private val categoryDao: CategoryDao
) {
    // Tasks
    val allTasks: Flow<List<TaskEntity>> = taskDao.getAllTasks()

    fun getTasksForDate(epochDay: Long): Flow<List<TaskEntity>> = taskDao.getTasksForDate(epochDay)

    fun getUpcomingTasks(epochDay: Long): Flow<List<TaskEntity>> = taskDao.getUpcomingTasks(epochDay)

    suspend fun getTaskById(id: Long): TaskEntity? = taskDao.getTaskById(id)

    suspend fun insertTask(task: TaskEntity): Long = taskDao.insertTask(task)

    suspend fun updateTask(task: TaskEntity) = taskDao.updateTask(task)

    suspend fun deleteTask(task: TaskEntity) = taskDao.deleteTask(task)

    suspend fun deleteTaskById(id: Long) = taskDao.deleteTaskById(id)

    suspend fun setTaskCompleted(id: Long, isCompleted: Boolean) {
        val completedAt = if (isCompleted) System.currentTimeMillis() else null
        taskDao.updateCompletion(id, isCompleted, completedAt)
    }

    // Notes
    val allNotes: Flow<List<NoteEntity>> = noteDao.getAllNotes()

    fun searchNotes(query: String): Flow<List<NoteEntity>> = noteDao.searchNotes(query)

    suspend fun getNoteById(id: Long): NoteEntity? = noteDao.getNoteById(id)

    suspend fun insertNote(note: NoteEntity): Long = noteDao.insertNote(note)

    suspend fun updateNote(note: NoteEntity) = noteDao.updateNote(note)

    suspend fun deleteNote(note: NoteEntity) = noteDao.deleteNote(note)

    suspend fun deleteNoteById(id: Long) = noteDao.deleteNoteById(id)

    suspend fun toggleNotePin(id: Long, isPinned: Boolean) = noteDao.updatePinStatus(id, isPinned)

    // Alarms
    val allAlarms: Flow<List<AlarmEntity>> = alarmDao.getAllAlarms()

    val activeAlarms: Flow<List<AlarmEntity>> = alarmDao.getActiveAlarms()

    suspend fun getActiveAlarmsSnapshot(): List<AlarmEntity> = alarmDao.getActiveAlarmsSnapshot()

    suspend fun getAlarmById(id: Long): AlarmEntity? = alarmDao.getAlarmById(id)

    suspend fun insertAlarm(alarm: AlarmEntity): Long = alarmDao.insertAlarm(alarm)

    suspend fun updateAlarm(alarm: AlarmEntity) = alarmDao.updateAlarm(alarm)

    suspend fun deleteAlarm(alarm: AlarmEntity) = alarmDao.deleteAlarm(alarm)

    suspend fun deleteAlarmById(id: Long) = alarmDao.deleteAlarmById(id)

    suspend fun setAlarmEnabled(id: Long, isEnabled: Boolean) = alarmDao.updateAlarmStatus(id, isEnabled)

    // Categories
    val allCategories: Flow<List<CategoryEntity>> = categoryDao.getAllCategories()

    suspend fun insertCategory(category: CategoryEntity) = categoryDao.insertCategory(category)

    suspend fun deleteCategory(category: CategoryEntity) = categoryDao.deleteCategory(category)

    // Snapshot backups
    suspend fun getAllTasksSnapshot(): List<TaskEntity> = taskDao.getAllTasksSnapshot()
    suspend fun getAllNotesSnapshot(): List<NoteEntity> = noteDao.getAllNotesSnapshot()
    suspend fun getAllAlarmsSnapshot(): List<AlarmEntity> = alarmDao.getAllAlarmsSnapshot()
    suspend fun getAllCategoriesSnapshot(): List<CategoryEntity> = categoryDao.getAllCategoriesSnapshot()

    suspend fun restoreDatabase(
        tasks: List<TaskEntity>,
        notes: List<NoteEntity>,
        alarms: List<AlarmEntity>,
        categories: List<CategoryEntity>
    ) {
        if (categories.isNotEmpty()) {
            categoryDao.insertDefaultCategories(categories)
        }
        if (tasks.isNotEmpty()) {
            taskDao.insertAll(tasks)
        }
        if (notes.isNotEmpty()) {
            noteDao.insertAll(notes)
        }
        if (alarms.isNotEmpty()) {
            alarmDao.insertAll(alarms)
        }
    }
}
