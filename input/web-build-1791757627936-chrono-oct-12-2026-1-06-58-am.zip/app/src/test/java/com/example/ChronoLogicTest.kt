package com.example

import com.example.data.model.AlarmEntity
import com.example.data.model.TaskPriority
import com.example.domain.alarm.AlarmScheduler
import com.example.ui.alarms.TimerState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ChronoLogicTest {

    @Test
    fun testAlarmEntityDaysParsing() {
        val alarmOneTime = AlarmEntity(
            hour = 8,
            minute = 30,
            recurringDays = ""
        )
        assertFalse(alarmOneTime.isRecurring())
        assertTrue(alarmOneTime.getDaysSet().isEmpty())

        val alarmWeekdays = AlarmEntity(
            hour = 7,
            minute = 0,
            recurringDays = "1,2,3,4,5"
        )
        assertTrue(alarmWeekdays.isRecurring())
        assertEquals(setOf(1, 2, 3, 4, 5), alarmWeekdays.getDaysSet())
    }

    @Test
    fun testOneTimeAlarmNextTriggerCalculation() {
        // Create a fixed "now" timestamp: 2026-10-11 10:00:00
        val nowCal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 11, 10, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val nowMillis = nowCal.timeInMillis

        // Alarm for 11:30 (today in future)
        val triggerFuture = AlarmScheduler.calculateNextTriggerMillis(
            targetHour = 11,
            targetMinute = 30,
            recurringDays = emptySet(),
            nowMillis = nowMillis
        )
        assertTrue(triggerFuture > nowMillis)
        val futureCal = Calendar.getInstance().apply { timeInMillis = triggerFuture }
        assertEquals(11, futureCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(11, futureCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(30, futureCal.get(Calendar.MINUTE))

        // Alarm for 08:00 (earlier than 10:00, must trigger tomorrow on Oct 12)
        val triggerPast = AlarmScheduler.calculateNextTriggerMillis(
            targetHour = 8,
            targetMinute = 0,
            recurringDays = emptySet(),
            nowMillis = nowMillis
        )
        assertTrue(triggerPast > nowMillis)
        val pastCal = Calendar.getInstance().apply { timeInMillis = triggerPast }
        assertEquals(12, pastCal.get(Calendar.DAY_OF_MONTH))
        assertEquals(8, pastCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, pastCal.get(Calendar.MINUTE))
    }

    @Test
    fun testRecurringAlarmNextTriggerCalculation() {
        // Monday 2026-10-12 at 09:00:00
        val mondayCal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 12, 9, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val mondayNow = mondayCal.timeInMillis

        // Set alarm recurring on Wednesday (day 3) and Friday (day 5) at 08:00
        // Wednesday Oct 14 should be next trigger!
        val trigger = AlarmScheduler.calculateNextTriggerMillis(
            targetHour = 8,
            targetMinute = 0,
            recurringDays = setOf(3, 5),
            nowMillis = mondayNow
        )

        assertTrue(trigger > mondayNow)
        val triggerCal = Calendar.getInstance().apply { timeInMillis = trigger }
        assertEquals(Calendar.WEDNESDAY, triggerCal.get(Calendar.DAY_OF_WEEK))
        assertEquals(8, triggerCal.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, triggerCal.get(Calendar.MINUTE))
    }

    @Test
    fun testTimerStateFormatting() {
        val timer5m = TimerState(
            remainingMillis = 5 * 60 * 1000L,
            totalMillis = 5 * 60 * 1000L
        )
        assertEquals("05:00", timer5m.formattedRemaining)
        assertEquals(1.0f, timer5m.progress, 0.001f)

        val timer1h2m3s = TimerState(
            remainingMillis = (3600 + 120 + 3) * 1000L,
            totalMillis = 3723 * 1000L
        )
        assertEquals("01:02:03", timer1h2m3s.formattedRemaining)

        val timerHalfDone = TimerState(
            remainingMillis = 30_000L,
            totalMillis = 60_000L
        )
        assertEquals(0.5f, timerHalfDone.progress, 0.001f)
    }

    @Test
    fun testTaskPriorityParsing() {
        assertEquals(TaskPriority.LOW, TaskPriority.fromString("LOW"))
        assertEquals(TaskPriority.MEDIUM, TaskPriority.fromString("medium"))
        assertEquals(TaskPriority.HIGH, TaskPriority.fromString("High"))
        assertEquals(TaskPriority.MEDIUM, TaskPriority.fromString("unknown_val"))
    }

    @Test
    fun testBottomNavItemsInitialized() {
        val items = com.example.ui.navigation.Screen.bottomNavItems
        assertEquals(5, items.size)
        items.forEach { screen ->
            org.junit.Assert.assertNotNull(screen)
            assertTrue(screen.route.isNotBlank())
            assertTrue(screen.title.isNotBlank())
        }
    }
}
